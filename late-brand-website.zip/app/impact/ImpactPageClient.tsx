"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Check, X } from 'lucide-react'
import emailjs from '@emailjs/browser'

export default function ImpactPageClient() {
  const [donationAmount, setDonationAmount] = useState(0)
  const [showWaitlistForm, setShowWaitlistForm] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isSending, setIsSending] = useState(false)
  const [emailSent, setEmailSent] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)
  const emailInputRef = useRef<HTMLInputElement>(null)

  // Simulate increasing donations over time
  useEffect(() => {
    const interval = setInterval(() => {
      setDonationAmount((prev) => {
        // Random small increment between $5-25
        const increment = Math.floor(Math.random() * 20) + 5
        return prev + increment
      })
    }, 10000) // Update every 10 seconds

    // Initial amount
    setDonationAmount(12750)

    return () => clearInterval(interval)
  }, [])

  // Format donation amount with commas
  const formattedDonation = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(donationAmount)

  // Check if the form was successfully submitted
  useEffect(() => {
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search)
      if (urlParams.get("submitted") === "waitlist") {
        setIsSubmitted(true)
        setShowWaitlistForm(true)

        // Clean up the URL after a delay
        setTimeout(() => {
          window.history.replaceState({}, document.title, window.location.pathname)
          // Close the modal after showing success message
          setTimeout(() => {
            setShowWaitlistForm(false)
            setIsSubmitted(false)
          }, 3000)
        }, 1000)
      }
    }
  }, [])

  // Initialize EmailJS
  useEffect(() => {
    emailjs.init("YOUR_EMAILJS_PUBLIC_KEY") // Replace with your actual public key
  }, [])

  // Add this handleSubmit function
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formRef.current || !emailInputRef.current?.value) return
    
    setIsSending(true)
    
    try {
      // First submit the form to Formspree
      const formData = new FormData(formRef.current)
      await fetch("https://formspree.io/f/xaygpbwv", {
        method: "POST",
        body: formData,
        headers: {
          Accept: "application/json",
        },
      })
      
      // Then send confirmation email
      const userEmail = emailInputRef.current.value
      
      // Send confirmation email using EmailJS
      await emailjs.send(
        "YOUR_SERVICE_ID", // Replace with your EmailJS service ID
        "YOUR_TEMPLATE_ID", // Replace with your EmailJS template ID
        {
          to_email: userEmail,
          form_type: "waitlist",
          message: "Thank you for joining the waitlist for our exclusive auction! We've received your submission and will notify you as soon as our limited edition items become available. Your interest in supporting the LATE movement and our initiatives is greatly appreciated. We look forward to sharing our vision for change with you and offering you first access to these exclusive pieces."
        }
      )
      
      setEmailSent(true)
      setIsSubmitted(true)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSending(false)
    }
  }

  return (
    <main className="min-h-screen bg-white dark:bg-black text-gray-900 dark:text-white">
      <section className="py-20 md:py-32">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-8 text-center">Our Impact</h1>

          <div className="max-w-3xl mx-auto space-y-12">
            <p className="text-xl text-gray-700 dark:text-zinc-300">
              LATE is more than a brand—it's a movement. We support creative minds, independent thinkers, and those who
              move on their own time. Our impact extends beyond fashion and philosophy; we're reshaping how society
              views success and time management.
            </p>

            {/* Commitment Section */}
            <div className="bg-gray-100 dark:bg-zinc-900 p-8 rounded-lg shadow-md dark:shadow-none">
              <h2 className="text-2xl font-bold mb-4">Our Commitment</h2>
              <p className="text-gray-700 dark:text-zinc-300 mb-6">
                As we launch the LATE brand, we are committed to dedicating{" "}
                <span className="text-purple-600 dark:text-purple-400 font-bold">20% of our yearly profits</span> to
                causes that are fundamental to our values, with a special focus on education.
              </p>
              <p className="text-gray-700 dark:text-zinc-300">
                We are currently structuring several initiatives and programs that will begin to be publicly announced
                in Fall 2025. These programs will focus on empowering individuals to pursue education and personal
                growth on their own timelines, free from conventional pressures.
              </p>
            </div>

            {/* Donation Counter */}
            <div className="bg-gradient-to-r from-purple-100 to-gray-100 dark:from-purple-900/50 dark:to-zinc-900 p-8 rounded-lg text-center shadow-md dark:shadow-none">
              <h2 className="text-2xl font-bold mb-4">Impact Fund</h2>
              <div className="text-4xl md:text-5xl font-bold text-purple-600 dark:text-white mb-4">
                {formattedDonation}
              </div>
              <p className="text-gray-700 dark:text-zinc-300">Raised so far for our initiatives</p>
            </div>

            {/* Limited Items Section */}
            <div className="bg-gray-100 dark:bg-zinc-900 p-8 rounded-lg shadow-md dark:shadow-none">
              <h2 className="text-2xl font-bold mb-4">Limited Edition Items</h2>
              <p className="text-gray-700 dark:text-zinc-300 mb-6">
                We will soon be launching exclusive items for sale, with proceeds directly supporting the LATE movement
                and our initiatives. These limited pieces represent not just ownership of art, but participation in our
                vision for change.
              </p>

              {/* Blurred Preview */}
              <div className="relative w-full aspect-video mb-6 overflow-hidden rounded-lg shadow-md dark:shadow-none">
                <div className="absolute inset-0 backdrop-blur-xl bg-black/30 flex items-center justify-center z-10">
                  <div className="text-center p-6">
                    <p className="text-white text-xl font-bold mb-2">Coming Soon</p>
                    <p className="text-zinc-300">Fall 2025</p>
                  </div>
                </div>
                <div className="relative w-full h-full">
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent z-[5]"></div>
                  <div className="w-full h-full relative">
                    <Image
                      src="/placeholder.svg?height=400&width=800"
                      alt="Blurred preview of LATE artwork featuring the moon"
                      fill
                      className="object-cover"
                      style={{
                        filter: "blur(8px) brightness(0.7)",
                        transform: "scale(1.1)",
                      }}
                    />
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-5xl font-bold z-[6] opacity-60">
                      LATE
                    </div>
                    <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-white text-xl z-[6] opacity-60">
                      The Moon Series
                    </div>
                  </div>
                </div>
              </div>

              {/* Auction Info */}
              <div className="bg-white dark:bg-zinc-800 p-6 rounded-lg shadow-sm dark:shadow-none">
                <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                  <div>
                    <h3 className="text-xl font-bold mb-2">Exclusive Auction</h3>
                    <p className="text-gray-700 dark:text-zinc-300">
                      Starting at <span className="text-purple-600 dark:text-purple-400 font-bold">$5,000</span>
                    </p>
                    <p className="text-gray-500 dark:text-zinc-400 text-sm mt-2">
                      Includes exclusive rights to be featured with the brand at related events and initiatives
                    </p>
                  </div>
                  <Button
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                    onClick={() => setShowWaitlistForm(true)}
                  >
                    Join Waitlist
                  </Button>
                </div>
              </div>
            </div>

            {/* Future Initiatives */}
            <div className="bg-gray-100 dark:bg-zinc-900 p-8 rounded-lg shadow-md dark:shadow-none">
              <h2 className="text-2xl font-bold mb-4">Future Initiatives</h2>
              <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-zinc-300">
                <li>Mentorship programs for young entrepreneurs</li>
                <li>Workshops on time management and productivity</li>
                <li>Scholarships for non-traditional students</li>
                <li>Partnerships with mental health organizations</li>
                <li>Community spaces for creative collaboration</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Waitlist Modal */}
      {showWaitlistForm && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-zinc-800 rounded-lg p-6 max-w-md w-full relative animate-fade-in shadow-xl dark:shadow-none">
            <button
              onClick={() => setShowWaitlistForm(false)}
              className="absolute top-4 right-4 text-gray-500 dark:text-zinc-400 hover:text-gray-700 dark:hover:text-white"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Join the Waitlist</h3>

            {!isSubmitted ? (
              <>
                <p className="text-gray-700 dark:text-zinc-300 mb-6">
                  Be the first to know when our exclusive auction launches. Enter your email to join the waitlist.
                </p>

                <form
                  ref={formRef}
                  onSubmit={handleSubmit}
                  className="space-y-4"
                >
                  {/* Hidden field to identify the form */}
                  <input type="hidden" name="form-name" value="auction-waitlist" />
                  <input type="hidden" name="_subject" value="New Auction Waitlist Signup" />

                  <div>
                    <label
                      htmlFor="waitlist-email"
                      className="block text-sm font-medium text-gray-700 dark:text-zinc-300 mb-1"
                    >
                      Email Address
                    </label>
                    <Input
                      id="waitlist-email"
                      name="email"
                      type="email"
                      ref={emailInputRef}
                      required
                      placeholder="your@email.com"
                      className="bg-white dark:bg-zinc-700 border-gray-300 dark:border-zinc-600"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                    disabled={isSending}
                  >
                    {isSending ? 'Processing...' : 'Join Waitlist'}
                  </Button>
                </form>
              </>
            ) : (
              <div className="text-center py-4">
                <div className="flex items-center justify-center mb-4">
                  <div className="bg-purple-600 rounded-full p-2">
                    <Check className="w-6 h-6 text-white" />
                  </div>
                </div>
                <h4 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">You're on the list!</h4>
                <p className="text-gray-700 dark:text-zinc-300">
                  Thank you for your interest. We'll notify you when the auction begins.
                </p>
                {emailSent && (
                  <p className="text-gray-500 dark:text-zinc-400 text-sm mt-2">
                    A confirmation email has been sent to your inbox.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </main>
  )
}

