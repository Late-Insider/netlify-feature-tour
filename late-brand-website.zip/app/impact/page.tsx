import type { Metadata } from "next"
import ImpactPageClient from "./ImpactPageClient"

export const metadata: Metadata = {
  title: "Impact | LATE - OWN YOUR TIME",
  description:
    "Discover how LATE is making an impact and supporting creative minds, independent thinkers, and those who move on their own time.",
}

export default function ImpactPage() {
  return <ImpactPageClient />
}

