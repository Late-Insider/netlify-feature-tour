import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import type { Metadata } from "next"
import { notFound } from "next/navigation"

interface BlogPost {
  id: number
  title: string
  excerpt: string
  slug: string
  content: string
}

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "The Art of Showing Up",
    excerpt: "It's not about being everywhere, it's about making your presence felt when you arrive.",
    slug: "the-art-of-showing-up",
    content: `
      <p>In a world that glorifies omnipresence, there's a subtle art to showing up that's often overlooked. It's not about being everywhere—it's about making your presence felt when you do arrive.</p>
      
      <p>Think about it: would you rather be remembered as the person who was at every event but left no impression, or the one whose arrival shifted the energy of the room? The latter requires intention, presence, and a clear understanding of your own value.</p>
      
      <p>When you show up with purpose, you bring your full self to the table. You're not distracted by where else you could be or what else you could be doing. You're fully present, and that presence is magnetic.</p>
      
      <p>This doesn't mean you should be fashionably late to everything. Rather, it means being deliberate about where and how you spend your energy. Choose the moments that matter, and when you're there, be there completely.</p>
      
      <p>The art of showing up isn't about timing—it's about impact. And impact is something you can create regardless of when you arrive.</p>
    `,
  },
  {
    id: 2,
    title: "The Hustle Myth",
    excerpt: "Why working harder doesn't always mean working better. Redefining productivity on your own terms.",
    slug: "the-hustle-myth",
    content: `
      <p>We've been sold a dangerous myth: that constant hustle is the only path to success. That if you're not working every waking hour, you're falling behind. That rest is for the weak.</p>
      
      <p>This hustle culture has created a generation of burnt-out individuals chasing an ever-moving finish line. But what if the most productive thing you could do was slow down?</p>
      
      <p>Research consistently shows that after a certain point, working more hours actually decreases productivity. Your brain needs rest to function optimally. Your creativity needs space to flourish.</p>
      
      <p>True productivity isn't about how many hours you work—it's about the value you create in the hours you do work. It's about working smarter, not harder. It's about recognizing that sometimes, the best thing you can do for your work is to step away from it.</p>
      
      <p>Redefine productivity on your own terms. Maybe that means working fewer hours but with more focus. Maybe it means taking longer breaks between intense work sessions. Maybe it means recognizing that your worth isn't tied to your output.</p>
      
      <p>The hustle myth wants you to believe that success is a race. But what if it's more like a dance—one where timing, rhythm, and presence matter more than speed?</p>
    `,
  },
  {
    id: 3,
    title: "Moving in Silence",
    excerpt: "The power of quiet progress and letting your success speak for itself.",
    slug: "moving-in-silence",
    content: `
      <p>There's a certain power in moving quietly. In working diligently behind the scenes without broadcasting every step of your journey.</p>
      
      <p>In an age of constant sharing and public goal-setting, there's something to be said for keeping your cards close to your chest. Not because you're secretive, but because some journeys are better traveled in solitude.</p>
      
      <p>When you move in silence, you protect your ideas from external influences. You give yourself the space to experiment, to fail, to pivot without explanation. You free yourself from the pressure of external validation.</p>
      
      <p>This doesn't mean you never share your work or celebrate your wins. It means you're selective about what you share and when. It means you understand that not every step of the process needs an audience.</p>
      
      <p>There's a reason why many of the most successful people are also the most private about their work until it's ready to be seen. They understand that true power lies in letting your success speak for itself.</p>
      
      <p>So move at your own pace, in your own way, without feeling the need to narrate every step. The right people will notice when the time is right.</p>
    `,
  },
  {
    id: 4,
    title: "Success Isn't a Deadline, It's a Destination",
    excerpt: "How to focus on the journey rather than arbitrary timelines.",
    slug: "success-isnt-a-deadline",
    content: `
      <p>We've been conditioned to view success through the lens of time. "I should be at X point by Y age." "This project needs to be completed by this date." "If I haven't achieved this milestone by that deadline, I've failed."</p>
      
      <p>But what if we've been looking at it all wrong? What if success isn't about meeting deadlines, but about reaching destinations—regardless of how long the journey takes?</p>
      
      <p>Think about the most meaningful achievements in your life. Were they valuable because you reached them quickly, or because of what they taught you along the way? Would they have been more significant if you'd reached them sooner?</p>
      
      <p>When we fixate on deadlines, we miss the richness of the journey. We rush past valuable lessons. We prioritize speed over depth.</p>
      
      <p>Instead, focus on the destination. Set your sights on where you want to go, but be flexible about how and when you get there. Understand that detours and delays aren't failures—they're part of your unique path.</p>
      
      <p>Success isn't a race against time. It's a journey toward becoming who you're meant to be. And that journey doesn't come with an expiration date.</p>
    `,
  },
  {
    id: 5,
    title: "Patience & Timing: The Power of Knowing When to Move",
    excerpt: "Understanding the delicate balance between patience and action.",
    slug: "patience-and-timing",
    content: `
      <p>In a world obsessed with immediate action, patience has become a forgotten virtue. We're constantly told to seize the day, to act now, to not waste a moment. But what if the most powerful move you could make was to wait?</p>
      
      <p>Patience isn't passive—it's strategic. It's about understanding that timing is everything. It's about recognizing that sometimes, the conditions aren't right yet for what you want to achieve.</p>
      
      <p>Think of a surfer waiting for the perfect wave. They don't paddle frantically at every ripple. They observe, they feel the rhythm of the ocean, and they wait for the moment when their effort will yield the greatest result.</p>
      
      <p>This doesn't mean you should sit idly by. While you're waiting, you're preparing. You're building your skills, gathering resources, studying the landscape. You're getting ready for the moment when it's time to move.</p>
      
      <p>The key is discernment—knowing the difference between procrastination and strategic patience. Procrastination comes from fear; patience comes from wisdom. Procrastination avoids; patience anticipates.</p>
      
      <p>So cultivate the wisdom to know when to wait and when to act. Trust that your timing is perfect for your unique journey. And remember that sometimes, the most powerful thing you can do is nothing at all—until the moment is right.</p>
    `,
  },
  {
    id: 6,
    title: "You Are Your Own Rescue",
    excerpt: "Finding strength within yourself when no one else is coming to save you.",
    slug: "you-are-your-own-rescue",
    content: `
      <p>There comes a moment in every person's life when they realize that no one is coming to save them. No knight in shining armor, no fairy godmother, no miraculous intervention. Just you, facing whatever challenge stands before you.</p>
      
      <p>This realization can be terrifying. But it can also be incredibly liberating.</p>
      
      <p>When you understand that you are your own rescue, you stop waiting for external validation or permission to change your circumstances. You stop hoping that someone else will fix your problems or create opportunities for you. You take full ownership of your life.</p>
      
      <p>This doesn't mean you have to do everything alone. It means recognizing that the ultimate responsibility for your well-being and success rests with you. It means understanding that while others can support you, guide you, and love you, they cannot live your life for you.</p>
      
      <p>Being your own rescue means developing self-trust. It means learning to listen to your intuition, to honor your needs, to set boundaries that protect your energy. It means building resilience so that when life knocks you down—as it inevitably will—you have the strength to get back up.</p>
      
      <p>So embrace the power that comes with being your own hero. Find the courage within yourself to face your fears, to pursue your dreams, to create the life you want. Because the truth is, you've always had everything you need inside you.</p>
    `,
  },
  {
    id: 7,
    title: "The Late Mindset: Thriving Outside Society's Timeline",
    excerpt: "Breaking free from societal expectations and creating your own definition of success.",
    slug: "the-late-mindset",
    content: `
      <p>Society has a very specific timeline for how your life should unfold. Graduate by this age. Get married by that age. Buy a house, have children, reach career milestones—all according to a predetermined schedule that leaves little room for individual differences or unexpected detours.</p>
      
      <p>But what happens when your life doesn't follow this script? What happens when you're "late" according to society's clock?</p>
      
      <p>The Late Mindset is about rejecting the notion that there's a universal timeline that everyone should adhere to. It's about understanding that life isn't a race with a standardized track, but a unique journey for each individual.</p>
      
      <p>When you embrace the Late Mindset, you free yourself from the anxiety of comparison. You recognize that your path is your own, and that what matters isn't when you reach certain milestones, but how meaningful they are when you do reach them.</p>
      
      <p>This mindset allows you to move at your own pace, to take detours that enrich your experience, to prioritize what truly matters to you rather than what society says should matter. It gives you permission to define success on your own terms.</p>
      
      <p>So if you find yourself "behind" according to conventional wisdom, remember: you're not late—you're right on time for your unique journey. And that journey is all the more beautiful for not being a carbon copy of everyone else's.</p>
    `,
  },
  {
    id: 8,
    title: "Rejection is Redirection",
    excerpt: "How closed doors lead to better opportunities and align you with your true path.",
    slug: "rejection-is-redirection",
    content: `
      <p>Rejection stings. Whether it's a job application, a romantic interest, or a creative project, hearing "no" can feel like a personal failure. But what if rejection isn't a dead end, but a signpost pointing you in a new direction?</p>
      
      <p>Every "no" you receive is clearing the path for a better "yes." Every door that closes is steering you toward the door you're actually meant to walk through. Rejection isn't a reflection of your worth—it's a redirection toward your destiny.</p>
      
      <p>Think about the rejections in your past. How many of them, in hindsight, were actually blessings in disguise? That job you didn't get that would have made you miserable. That relationship that didn't work out with someone who wasn't right for you. That opportunity you missed that would have taken you down a path that wasn't aligned with your true purpose.</p>
      
      <p>When you view rejection as redirection, you shift from a victim mentality to an empowered one. Instead of asking "Why is this happening to me?" you ask "Where is this leading me?" Instead of dwelling on what you've lost, you become curious about what you might find.</p>
      
      <p>This perspective doesn't mean you won't feel disappointed or hurt when faced with rejection. Those feelings are natural and valid. But it does mean that beneath those feelings, you can maintain a sense of trust in the greater unfolding of your life.</p>
      
      <p>So the next time you hear "no," remember: it's not a period at the end of your story. It's a comma, a pause before the next chapter begins—a chapter that might be even better than the one you had planned.</p>
    `,
  },
  {
    id: 9,
    title: "The Power of Being Unapologetically You",
    excerpt: "Embracing your authentic self without compromise or explanation.",
    slug: "being-unapologetically-you",
    content: `
      <p>In a world that constantly tries to shape you into something you're not, being yourself is a revolutionary act. It takes courage to stand firmly in your truth when society rewards conformity and punishes authenticity.</p>
      
      <p>Being unapologetically you doesn't mean being rude or inconsiderate of others. It means honoring your values, preferences, and boundaries without feeling the need to justify them. It means expressing your unique perspective without diluting it to make others comfortable.</p>
      
      <p>When you embrace your authentic self, you attract the right people and opportunities into your life. You no longer waste energy trying to fit into spaces where you don't belong. You create a life that feels aligned with who you truly are, not who you think you should be.</p>
      
      <p>This journey isn't always easy. Being authentic often means standing alone, being misunderstood, or facing criticism. It means being willing to disappoint others rather than betraying yourself. It means trusting that your uniqueness is your greatest strength, not a liability to be hidden.</p>
      
      <p>But the freedom that comes with authenticity is worth every uncomfortable moment. There's a profound peace in knowing that you're living your truth, regardless of external approval. There's power in the integrity of being the same person in every room you enter.</p>
      
      <p>So dare to be unapologetically you. The world doesn't need another carbon copy—it needs your unique voice, your unique perspective, your unique contribution. And you need the liberation that comes from finally putting down the heavy burden of pretending to be someone you're not.</p>
    `,
  },
  {
    id: 10,
    title: "The Fear of Falling Behind (And Why It's a Lie)",
    excerpt: "Dismantling the myth that everyone else is ahead and you're lagging behind.",
    slug: "fear-of-falling-behind",
    content: `
      <p>It lurks in the back of your mind as you scroll through social media. It whispers to you when you hear about a peer's accomplishment. It keeps you up at night when you reflect on your progress. The fear of falling behind—a modern anxiety that plagues so many of us.</p>
      
      <p>But here's the truth: this fear is based on a lie. The lie that there's a single, linear path to success that everyone is walking at the same pace. The lie that someone else's milestone is a measuring stick for your own journey. The lie that life is a race with a clearly defined finish line.</p>
      
      <p>In reality, each person's path is unique, with its own twists, turns, and timing. What looks like "falling behind" might actually be taking a necessary detour that will ultimately enrich your journey. What feels like "not enough progress" might be a period of important internal growth that isn't visible from the outside.</p>
      
      <p>Moreover, the highlight reels we see of others' lives rarely show the full picture. Behind every "overnight success" are years of struggle, failure, and perseverance. Behind every perfect social media post are messy, complicated realities that mirror your own.</p>
      
      <p>When you release the fear of falling behind, you free up enormous amounts of mental and emotional energy. You can focus on your own path without the constant distraction of comparison. You can celebrate others' successes without feeling diminished by them. You can move at a pace that feels right for you, rather than one dictated by external pressures.</p>
      
      <p>So the next time that fear creeps in, remember: you're not falling behind. You're simply walking your own path, at your own pace, toward your own destination. And that path is exactly where you're meant to be.</p>
    `,
  },
]

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const post = blogPosts.find((post) => post.slug === params.slug)

  if (!post) {
    return {
      title: "Post Not Found - LATE",
      description: "The requested blog post could not be found.",
    }
  }

  return {
    title: `${post.title} - LATE`,
    description: post.excerpt,
    openGraph: {
      title: `${post.title} - LATE`,
      description: post.excerpt,
      type: "article",
    },
  }
}

export default function BlogPost({ params }: { params: { slug: string } }) {
  const post = blogPosts.find((post) => post.slug === params.slug)

  if (!post) {
    notFound()
  }

  return (
    <main className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <Link
            href="/#blog"
            className="inline-flex items-center text-purple-400 hover:text-purple-300 mb-8 transition-colors"
          >
            <ArrowLeft className="mr-2 w-4 h-4" />
            Back to Blog
          </Link>

          <article>
            <h1 className="text-3xl md:text-5xl font-bold mb-6">{post.title}</h1>
            <p className="text-xl text-zinc-400 mb-10">{post.excerpt}</p>

            <div
              className="prose prose-lg prose-invert max-w-none prose-p:text-zinc-300 prose-headings:text-white"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
          </article>
        </div>
      </div>
    </main>
  )
}

