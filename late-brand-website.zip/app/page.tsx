import Link from "next/link"
import { ArrowDown } from "lucide-react"
import BlogGrid from "@/components/blog-grid"
import ShopTeaser from "@/components/shop-teaser"
import ContactSection from "@/components/contact-section"
import PodcastSection from "@/components/podcast-section"
import BookSection from "@/components/book-section"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "LATE - OWN YOUR TIME",
  description: "Because success isn't about being on time. It's about making an impact when you arrive.",
  keywords: ["late", "time management", "success", "mindset", "lifestyle"],
  openGraph: {
    title: "LATE - OWN YOUR TIME",
    description: "Because success isn't about being on time. It's about making an impact when you arrive.",
    url: "https://late.ltd",
    siteName: "Late",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "LATE - OWN YOUR TIME",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "LATE - OWN YOUR TIME",
    description: "Because success isn't about being on time. It's about making an impact when you arrive.",
    images: ["/og-image.jpg"],
  },
}

export default function Home() {
  return (
    <main className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section id="hero" className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage:
              'url("https://hebbkx1anhila5yf.public.blob.vercel-storage.com/FB_IMG_1740971644630.jpg-xad6JTwvKbwdEbC3DJUI4Nha9PsN70.jpeg")',
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            filter: "grayscale(100%) brightness(40%)",
          }}
        />
        <div className="absolute inset-0 bg-black/60 dark:bg-black/60 z-10"></div>
        <div className="container mx-auto px-4 z-20">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1
              className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tighter leading-tight animate-fade-in text-white"
              style={{ animationDelay: "0.2s" }}
            >
              LATE - OWN YOUR TIME
            </h1>
            <p
              className="text-xl md:text-2xl text-zinc-300 max-w-2xl mx-auto animate-fade-in"
              style={{ animationDelay: "0.4s" }}
            >
              Because success isn't about being on time. It's about making an impact when you arrive.
            </p>
            <div className="pt-6 animate-fade-in" style={{ animationDelay: "0.6s" }}>
              <Link
                href="#mission"
                className="inline-flex items-center gap-2 bg-white text-black px-8 py-3 rounded-full font-medium hover:bg-purple-500 hover:text-white transition-all duration-300 transform hover:scale-105"
              >
                Explore
              </Link>
            </div>
          </div>
        </div>
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce z-20">
          <Link href="#mission" aria-label="Scroll to mission section">
            <ArrowDown className="w-8 h-8 text-white/70" />
          </Link>
        </div>
      </section>

      {/* Mission Section */}
      <section id="mission" className="py-24 md:py-32 bg-gray-100 dark:bg-zinc-900">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-8 text-gray-900 dark:text-white">Our Mission</h2>
            <p className="text-xl md:text-2xl text-gray-700 dark:text-zinc-300 mb-16 leading-relaxed">
              At LATE, we're on a mission to redefine success and empower individuals to thrive on their own timelines.
              We believe that true achievement comes not from racing against the clock, but from making a meaningful
              impact when the moment is right.
            </p>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white dark:bg-zinc-800 p-8 rounded-lg shadow-md dark:shadow-none transform transition-all duration-300 hover:scale-105 hover:bg-gray-50 dark:hover:bg-zinc-700">
                <h3 className="text-2xl font-bold mb-4 text-purple-600 dark:text-purple-400">Embrace Your Pace</h3>
                <p className="text-gray-700 dark:text-zinc-300">
                  We encourage you to move at a rhythm that feels authentic to you, free from the pressure of arbitrary
                  deadlines.
                </p>
              </div>
              <div className="bg-white dark:bg-zinc-800 p-8 rounded-lg shadow-md dark:shadow-none transform transition-all duration-300 hover:scale-105 hover:bg-gray-50 dark:hover:bg-zinc-700">
                <h3 className="text-2xl font-bold mb-4 text-purple-600 dark:text-purple-400">Quality Over Speed</h3>
                <p className="text-gray-700 dark:text-zinc-300">
                  We value thoughtful progress and meaningful outcomes over rushed results and empty achievements.
                </p>
              </div>
              <div className="bg-white dark:bg-zinc-800 p-8 rounded-lg shadow-md dark:shadow-none transform transition-all duration-300 hover:scale-105 hover:bg-gray-50 dark:hover:bg-zinc-700">
                <h3 className="text-2xl font-bold mb-4 text-purple-600 dark:text-purple-400">Redefine Success</h3>
                <p className="text-gray-700 dark:text-zinc-300">
                  We're here to challenge conventional notions of success and help you create a life that aligns with
                  your true values.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Book Section */}
      <BookSection />

      {/* Blog Section */}
      <BlogGrid />

      {/* Shop Section */}
      <ShopTeaser />

      {/* Podcast Section */}
      <PodcastSection />

      {/* Contact Section */}
      <ContactSection />
    </main>
  )
}

