"use client"

import { useState, useEffect, useRef } from "react"
import { Check } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import emailjs from '@emailjs/browser'

export default function ShopTeaser() {
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isSending, setIsSending] = useState(false)
  const [emailSent, setEmailSent] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)
  const emailInputRef = useRef<HTMLInputElement>(null)

  // Initialize EmailJS
  useEffect(() => {
    emailjs.init("YOUR_EMAILJS_PUBLIC_KEY") // Replace with your actual public key
  }, [])

  // Check if the form was successfully submitted
  useEffect(() => {
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search)
      if (urlParams.get("submitted") === "shop") {
        setIsSubmitted(true)

        // Clean up the URL
        window.history.replaceState({}, document.title, window.location.pathname)
      }
    }
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formRef.current || !emailInputRef.current?.value) return
    
    setIsSending(true)
    
    try {
      // First submit the form to Formspree
      const formData = new FormData(formRef.current)
      await fetch("https://formspree.io/f/xaygpbwv", {
        method: "POST",
        body: formData,
        headers: {
          Accept: "application/json",
        },
      })
      
      // Then send confirmation email
      const userEmail = emailInputRef.current.value
      
      // Send confirmation email using EmailJS
      await emailjs.send(
        "YOUR_SERVICE_ID", // Replace with your EmailJS service ID
        "YOUR_TEMPLATE_ID", // Replace with your EmailJS template ID
        {
          to_email: userEmail,
          form_type: "shop",
          message: "Thank you for your interest in the LATE Collection! We've received your submission and will notify you as soon as our exclusive merchandise drops. We appreciate your support and interest in joining the LATE movement. Stay tuned for unique, quality pieces that embody our philosophy coming your way soon!"
        }
      )
      
      setEmailSent(true)
      setIsSubmitted(true)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSending(false)
    }
  }

  return (
    <section id="shop" className="py-24 bg-white dark:bg-black relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-100/20 via-white to-white dark:from-purple-900/20 dark:via-black dark:to-black"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 dark:text-white">Coming Soon: The Late Collection</h2>
          <div className="bg-white dark:bg-zinc-800 p-8 rounded-lg shadow-md dark:shadow-none">
            <h3 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Exclusive Merch</h3>
            <p className="text-xl text-gray-600 dark:text-zinc-400 mb-6">Stay tuned. The drop is coming.</p>

            {!isSubmitted ? (
              <form
                ref={formRef}
                onSubmit={handleSubmit}
                className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
              >
                {/* Hidden field to identify the form */}
                <input type="hidden" name="form-name" value="shop-notification" />
                <input type="hidden" name="_subject" value="New Shop Collection Notification Signup" />

                <Input
                  ref={emailInputRef}
                  type="email"
                  name="email"
                  placeholder="Your email address"
                  required
                  className="bg-white dark:bg-zinc-700 border-gray-300 dark:border-zinc-600"
                />
                <Button
                  type="submit"
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                  disabled={isSending}
                >
                  {isSending ? 'Sending...' : 'Notify Me'}
                </Button>
              </form>
            ) : (
              <div className="bg-gray-100 dark:bg-zinc-700 p-4 rounded-lg text-center animate-fade-in max-w-md mx-auto">
                <div className="flex items-center justify-center mb-2">
                  <div className="bg-purple-600 rounded-full p-1">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                </div>
                <p className="text-gray-700 dark:text-zinc-300">
                  Thanks! We'll notify you when our collection drops.
                </p>
                {emailSent && (
                  <p className="text-gray-500 dark:text-zinc-400 text-sm mt-2">
                    A confirmation email has been sent to your inbox.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

