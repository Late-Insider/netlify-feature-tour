export default function ImpactSection() {
  return (
    <section className="py-24 bg-zinc-900">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-8">Impact & Mission</h2>
          <div className="bg-zinc-800 p-8 rounded-lg">
            <p className="text-xl text-zinc-300">
              Late is more than a brand—it's a movement. We support creative minds, independent thinkers, and those who
              move on their own time. Join us in making an impact through fashion, philosophy, and personal growth.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

