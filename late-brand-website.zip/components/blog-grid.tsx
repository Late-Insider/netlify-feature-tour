import Link from "next/link"
import { ArrowRight } from "lucide-react"

interface BlogPost {
  id: number
  title: string
  excerpt: string
  slug: string
}

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "The Art of Showing Up",
    excerpt: "It's not about being everywhere, it's about making your presence felt when you arrive.",
    slug: "the-art-of-showing-up",
  },
  {
    id: 2,
    title: "The Hustle Myth",
    excerpt: "Why working harder doesn't always mean working better. Redefining productivity on your own terms.",
    slug: "the-hustle-myth",
  },
  {
    id: 3,
    title: "Moving in Silence",
    excerpt: "The power of quiet progress and letting your success speak for itself.",
    slug: "moving-in-silence",
  },
  {
    id: 4,
    title: "Success Isn't a Deadline, It's a Destination",
    excerpt: "How to focus on the journey rather than arbitrary timelines.",
    slug: "success-isnt-a-deadline",
  },
  {
    id: 5,
    title: "Patience & Timing: The Power of Knowing When to Move",
    excerpt: "Understanding the delicate balance between patience and action.",
    slug: "patience-and-timing",
  },
  {
    id: 6,
    title: "You Are Your Own Rescue",
    excerpt: "Finding strength within yourself when no one else is coming to save you.",
    slug: "you-are-your-own-rescue",
  },
  {
    id: 7,
    title: "The Late Mindset: Thriving Outside Society's Timeline",
    excerpt: "Breaking free from societal expectations and creating your own definition of success.",
    slug: "the-late-mindset",
  },
  {
    id: 8,
    title: "Rejection is Redirection",
    excerpt: "How closed doors lead to better opportunities and align you with your true path.",
    slug: "rejection-is-redirection",
  },
  {
    id: 9,
    title: "The Power of Being Unapologetically You",
    excerpt: "Embracing your authentic self without compromise or explanation.",
    slug: "being-unapologetically-you",
  },
  {
    id: 10,
    title: "The Fear of Falling Behind (And Why It's a Lie)",
    excerpt: "Dismantling the myth that everyone else is ahead and you're lagging behind.",
    slug: "fear-of-falling-behind",
  },
]

export default function BlogGrid() {
  return (
    <section id="blog" className="py-24 bg-gray-100 dark:bg-zinc-900">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-gray-900 dark:text-white">
            LATE THOUGHTS
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <div
                key={post.id}
                className="bg-white dark:bg-zinc-800 rounded-lg overflow-hidden hover:bg-gray-50 dark:hover:bg-zinc-700 transition-all duration-300 transform hover:scale-[1.02] hover:shadow-xl shadow-md dark:shadow-none"
              >
                <div className="p-6 flex flex-col h-full">
                  <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">{post.title}</h3>
                  <p className="text-gray-600 dark:text-zinc-400 mb-4 flex-grow">{post.excerpt}</p>
                  <Link
                    href={`/blog/${post.slug}`}
                    className="inline-flex items-center text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 transition-colors group"
                  >
                    Read More
                    <ArrowRight className="ml-2 w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

