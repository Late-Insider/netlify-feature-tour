"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { usePathname } from "next/navigation"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Function to handle contact link click
  const handleContactClick = (e: React.MouseEvent) => {
    e.preventDefault()

    // Close mobile menu if open
    if (isMenuOpen) {
      setIsMenuOpen(false)
    }

    // If not on home page, navigate to home page first, then scroll
    if (pathname !== "/") {
      window.location.href = "/#contact"
      return
    }

    // If on home page, just scroll to contact section
    const contactSection = document.querySelector("#contact")
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  // Function to handle section navigation
  const handleSectionClick = (e: React.MouseEvent, sectionId: string) => {
    e.preventDefault()

    // Close mobile menu if open
    if (isMenuOpen) {
      setIsMenuOpen(false)
    }

    // If not on home page, navigate to home page first, then scroll
    if (pathname !== "/") {
      window.location.href = `/#${sectionId}`
      return
    }

    // If on home page, just scroll to the section
    const section = document.querySelector(`#${sectionId}`)
    if (section) {
      section.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? "bg-white/80 dark:bg-black/80 backdrop-blur-md py-4" : "bg-transparent py-6"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold tracking-tighter">
            LATE
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors">
              Home
            </Link>
            <a
              href="#mission"
              onClick={(e) => handleSectionClick(e, "mission")}
              className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
            >
              Mission
            </a>
            <a
              href="#book"
              onClick={(e) => handleSectionClick(e, "book")}
              className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
            >
              Book
            </a>
            <Link href="/impact" className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors">
              Impact
            </Link>
            <a
              href="#podcast"
              onClick={(e) => handleSectionClick(e, "podcast")}
              className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
            >
              Podcast
            </a>
            <a
              href="#blog"
              onClick={(e) => handleSectionClick(e, "blog")}
              className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
            >
              Blog
            </a>
            <a
              href="#shop"
              onClick={(e) => handleSectionClick(e, "shop")}
              className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
            >
              Shop
            </a>
            <a
              href="#contact"
              onClick={handleContactClick}
              className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
            >
              Contact
            </a>
            <ThemeToggle />
          </nav>

          <div className="md:hidden flex items-center gap-4">
            <ThemeToggle />
            {/* Mobile Menu Button */}
            <button
              className="text-black dark:text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label={isMenuOpen ? "Close menu" : "Open menu"}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white/95 dark:bg-black/95 backdrop-blur-md animate-fade-in">
          <nav className="container mx-auto px-4 py-6 flex flex-col space-y-4">
            <Link
              href="/"
              className="text-xl py-2 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <a
              href="#mission"
              className="text-xl py-2 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
              onClick={(e) => handleSectionClick(e, "mission")}
            >
              Mission
            </a>
            <a
              href="#book"
              className="text-xl py-2 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
              onClick={(e) => handleSectionClick(e, "book")}
            >
              Book
            </a>
            <Link
              href="/impact"
              className="text-xl py-2 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Impact
            </Link>
            <a
              href="#podcast"
              className="text-xl py-2 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
              onClick={(e) => handleSectionClick(e, "podcast")}
            >
              Podcast
            </a>
            <a
              href="#blog"
              className="text-xl py-2 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
              onClick={(e) => handleSectionClick(e, "blog")}
            >
              Blog
            </a>
            <a
              href="#shop"
              className="text-xl py-2 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
              onClick={(e) => handleSectionClick(e, "shop")}
            >
              Shop
            </a>
            <a
              href="#contact"
              className="text-xl py-2 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
              onClick={handleContactClick}
            >
              Contact
            </a>
          </nav>
        </div>
      )}
    </header>
  )
}

