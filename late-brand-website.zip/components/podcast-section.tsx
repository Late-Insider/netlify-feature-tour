"use client"

import { useState, useEffect, useRef } from "react"
import { Check } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import emailjs from '@emailjs/browser'

export default function PodcastSection() {
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [isSending, setIsSending] = useState(false)
  const [emailSent, setEmailSent] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)
  const emailInputRef = useRef<HTMLInputElement>(null)

  // Initialize EmailJS
  useEffect(() => {
    emailjs.init("YOUR_EMAILJS_PUBLIC_KEY") // Replace with your actual public key
  }, [])

  // Check if the form was successfully submitted
  useEffect(() => {
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search)
      if (urlParams.get("submitted") === "podcast") {
        setIsSubmitted(true)
        setShowForm(true)

        // Clean up the URL
        setTimeout(() => {
          window.history.replaceState({}, document.title, window.location.pathname)
        }, 2000)
      }
    }
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formRef.current || !emailInputRef.current?.value) return
    
    setIsSending(true)
    
    try {
      // First submit the form to Formspree
      const formData = new FormData(formRef.current)
      await fetch("https://formspree.io/f/xaygpbwv", {
        method: "POST",
        body: formData,
        headers: {
          Accept: "application/json",
        },
      })
      
      // Then send confirmation email
      const userEmail = emailInputRef.current.value
      
      // Send confirmation email using EmailJS
      await emailjs.send(
        "YOUR_SERVICE_ID", // Replace with your EmailJS service ID
        "YOUR_TEMPLATE_ID", // Replace with your EmailJS template ID
        {
          to_email: userEmail,
          form_type: "podcast",
          message: "Thank you for your interest in the Left Righteously podcast! We've received your submission and will notify you as soon as our first episodes are released. We appreciate your support and interest in joining the LATE movement. Stay tuned for thought-provoking content coming your way soon!"
        }
      )
      
      setEmailSent(true)
      setIsSubmitted(true)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSending(false)
    }
  }

  return (
    <section id="podcast" className="py-24 bg-gray-100 dark:bg-zinc-900">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-gray-900 dark:text-white">Left Righteously - The Podcast</h2>
          <div className="bg-white dark:bg-zinc-800 p-8 rounded-lg shadow-md dark:shadow-none">
            <p className="text-xl text-gray-700 dark:text-zinc-300 mb-6">
              Diving deep into philosophy, spirituality, and the art of thinking differently. Stay tuned for our first
              episodes.
            </p>

            {!showForm ? (
              <Button
                onClick={() => setShowForm(true)}
                className="inline-flex items-center gap-2 bg-purple-600 text-white px-6 py-3 rounded-full font-medium hover:bg-purple-700 transition-all duration-300"
              >
                Get Notified
              </Button>
            ) : !isSubmitted ? (
              <div className="max-w-md mx-auto">
                <form
                  ref={formRef}
                  onSubmit={handleSubmit}
                  className="flex flex-col sm:flex-row gap-3"
                >
                  {/* Hidden field to identify the form */}
                  <input type="hidden" name="form-name" value="podcast-notification" />
                  <input type="hidden" name="_subject" value="New Podcast Notification Signup" />
                  
                  <Input
                    ref={emailInputRef}
                    type="email"
                    name="email"
                    placeholder="Your email address"
                    required
                    className="bg-white dark:bg-zinc-700 border-gray-300 dark:border-zinc-600"
                  />
                  <Button 
                    type="submit"
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                    disabled={isSending}
                  >
                    {isSending ? 'Sending...' : 'Notify Me'}
                  </Button>
                </form>
              </div>
            ) : (
              <div className="bg-gray-100 dark:bg-zinc-700 p-4 rounded-lg text-center animate-fade-in max-w-md mx-auto">
                <div className="flex items-center justify-center mb-2">
                  <div className="bg-purple-600 rounded-full p-1">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                </div>
                <p className="text-gray-700 dark:text-zinc-300">
                  Thanks! We'll notify you when our podcast launches.
                </p>
                {emailSent && (
                  <p className="text-gray-500 dark:text-zinc-400 text-sm mt-2">
                    A confirmation email has been sent to your inbox.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

