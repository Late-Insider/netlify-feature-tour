"use client"

import { useState, useEffect, useRef } from "react"
import { ArrowLeft, ArrowRight, Check } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import Image from "next/image"
import emailjs from '@emailjs/browser'

// Launch date: April 1st, 2025 at 01:17 AM Athens time
const LAUNCH_DATE = new Date("2025-04-01T01:17:00+02:00").getTime()

const bookCovers = [
  {
    id: 1,
    type: "front",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1_20250306_222459_0000.png-XCgeoHBuVYl5aqivahHf1VAO1p1s73.jpeg",
    alt: "The Ultimate Truth - Front Cover",
  },
  {
    id: 2,
    type: "back",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/2_20250306_222500_0001.png-Ykdu55CByz7R9niBVp0MYGELCT2LP7.jpeg",
    alt: "The Ultimate Truth - Back Cover",
  },
]

export default function BookSection() {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  })

  const [currentCover, setCurrentCover] = useState(0)
  const [isSubmitted, setIsSubmitted] = useState(false)

  // Inside the component, add these new state variables and refs
  const [isSending, setIsSending] = useState(false)
  const [emailSent, setEmailSent] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)
  const emailInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime()
      const distance = LAUNCH_DATE - now

      if (distance < 0) {
        clearInterval(timer)
        setTimeLeft({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
        })
        return
      }

      setTimeLeft({
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((distance % (1000 * 60)) / 1000),
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // Check if the form was successfully submitted (Formspree redirects back with a query param)
  useEffect(() => {
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search)
      if (urlParams.get("submitted") === "book") {
        setIsSubmitted(true)

        // Clean up the URL
        window.history.replaceState({}, document.title, window.location.pathname)
      }
    }
  }, [])

  // Initialize EmailJS
  useEffect(() => {
    emailjs.init("YOUR_EMAILJS_PUBLIC_KEY") // Replace with your actual public key
  }, [])

  const nextCover = () => {
    if (currentCover < bookCovers.length - 1) {
      setCurrentCover(currentCover + 1)
    }
  }

  const prevCover = () => {
    if (currentCover > 0) {
      setCurrentCover(currentCover - 1)
    }
  }

  // Add this handleSubmit function
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formRef.current || !emailInputRef.current?.value) return
    
    setIsSending(true)
    
    try {
      // First submit the form to Formspree
      const formData = new FormData(formRef.current)
      await fetch("https://formspree.io/f/xaygpbwv", {
        method: "POST",
        body: formData,
        headers: {
          Accept: "application/json",
        },
      })
      
      // Then send confirmation email
      const userEmail = emailInputRef.current.value
      
      // Send confirmation email using EmailJS
      await emailjs.send(
        "YOUR_SERVICE_ID", // Replace with your EmailJS service ID
        "YOUR_TEMPLATE_ID", // Replace with your EmailJS template ID
        {
          to_email: userEmail,
          form_type: "book",
          message: "Thank you for pre-ordering 'The Ultimate Truth'! We've received your reservation and will notify you when the book launches on April 1st, 2025. Your support means the world to us, and we're excited to share this journey with you as part of the LATE movement. We look forward to delivering this exclusive signed edition to you with your 30% discount and priority shipping."
        }
      )
      
      setEmailSent(true)
      setIsSubmitted(true)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSending(false)
    }
  }

  return (
    <section id="book" className="py-24 bg-white dark:bg-black relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-100/20 via-white to-white dark:from-purple-900/20 dark:via-black dark:to-black"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center text-gray-900 dark:text-white">The Book</h2>

          {/* Countdown Timer */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-center mb-8 text-gray-900 dark:text-white">Launching In:</h3>
            <div className="flex justify-center gap-4 md:gap-8">
              <div className="bg-gray-100 dark:bg-zinc-800 p-4 md:p-6 rounded-lg text-center min-w-[80px] md:min-w-[100px] shadow-md dark:shadow-none">
                <div className="text-3xl md:text-5xl font-bold text-purple-600 dark:text-purple-400">
                  {timeLeft.days}
                </div>
                <div className="text-sm md:text-base text-gray-500 dark:text-zinc-400">Days</div>
              </div>
              <div className="bg-gray-100 dark:bg-zinc-800 p-4 md:p-6 rounded-lg text-center min-w-[80px] md:min-w-[100px] shadow-md dark:shadow-none">
                <div className="text-3xl md:text-5xl font-bold text-purple-600 dark:text-purple-400">
                  {timeLeft.hours}
                </div>
                <div className="text-sm md:text-base text-gray-500 dark:text-zinc-400">Hours</div>
              </div>
              <div className="bg-gray-100 dark:bg-zinc-800 p-4 md:p-6 rounded-lg text-center min-w-[80px] md:min-w-[100px] shadow-md dark:shadow-none">
                <div className="text-3xl md:text-5xl font-bold text-purple-600 dark:text-purple-400">
                  {timeLeft.minutes}
                </div>
                <div className="text-sm md:text-base text-gray-500 dark:text-zinc-400">Minutes</div>
              </div>
              <div className="bg-gray-100 dark:bg-zinc-800 p-4 md:p-6 rounded-lg text-center min-w-[80px] md:min-w-[100px] shadow-md dark:shadow-none">
                <div className="text-3xl md:text-5xl font-bold text-purple-600 dark:text-purple-400">
                  {timeLeft.seconds}
                </div>
                <div className="text-sm md:text-base text-gray-500 dark:text-zinc-400">Seconds</div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Book Preview */}
            <div className="flex flex-col items-center">
              <div className="relative mb-6 w-[300px] md:w-[400px] aspect-[2/3]">
                <div className="relative w-full h-full transform transition-transform duration-500 shadow-2xl">
                  <Image
                    src={bookCovers[currentCover].url || "/placeholder.svg"}
                    alt={bookCovers[currentCover].alt}
                    fill
                    className="object-cover rounded-lg"
                    priority
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={prevCover}
                  disabled={currentCover === 0}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" /> Front Cover
                </Button>
                <Button
                  onClick={nextCover}
                  disabled={currentCover === bookCovers.length - 1}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  Back Cover <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Pre-order Form */}
            <div className="bg-white dark:bg-zinc-800 p-8 rounded-lg shadow-md dark:shadow-none">
              <h3 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Pre-order Your Copy</h3>

              <div className="mb-6">
                <p className="text-gray-700 dark:text-zinc-300 mb-4">
                  Reserve your exclusive signed copy of "The Ultimate Truth" today and receive a 30% discount when the
                  book launches on April 1st, 2025.
                </p>
                <ul className="list-disc list-inside text-gray-600 dark:text-zinc-400 space-y-2">
                  <li>Exclusive signed edition by A. Phoenix</li>
                  <li>30% off the retail price</li>
                  <li>Priority shipping</li>
                  <li>Email notification when the book launches</li>
                </ul>
              </div>

              {!isSubmitted ? (
                <form 
                  ref={formRef}
                  onSubmit={handleSubmit}
                  className="space-y-4"
                >
                  {/* Hidden field to identify the form */}
                  <input type="hidden" name="form-name" value="book-preorder" />
                  <input type="hidden" name="_subject" value="New Book Pre-order" />
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-zinc-300 mb-1">
                      Email Address
                    </label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      ref={emailInputRef}
                      required
                      placeholder="your@email.com"
                      className="bg-white dark:bg-zinc-700 border-gray-300 dark:border-zinc-600"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="comment" className="block text-sm font-medium text-gray-700 dark:text-zinc-300 mb-1">
                      Why are you interested in this book?
                    </label>
                    <Textarea
                      id="comment"
                      name="comment"
                      required
                      placeholder="Share your thoughts..."
                      className="bg-white dark:bg-zinc-700 border-gray-300 dark:border-zinc-600 min-h-[100px]"
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                    disabled={isSending}
                  >
                    {isSending ? 'Processing...' : 'Reserve My Copy'}
                  </Button>
                </form>
              ) : (
                <div className="bg-gray-100 dark:bg-zinc-700 p-6 rounded-lg text-center animate-fade-in">
                  <div className="flex items-center justify-center mb-4">
                    <div className="bg-purple-600 rounded-full p-2">
                      <Check className="w-6 h-6 text-white" />
                    </div>
                  </div>
                  <h4 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">Pre-order Reserved!</h4>
                  <p className="text-gray-700 dark:text-zinc-300">
                    Thank you for your interest! We'll notify you when the book launches on April 1st, 2025.
                  </p>
                  {emailSent && (
                    <p className="text-gray-500 dark:text-zinc-400 text-sm mt-2">
                      A confirmation email has been sent to your inbox.
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

