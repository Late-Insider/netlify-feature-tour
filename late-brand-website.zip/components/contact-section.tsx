import Link from "next/link"
import { Instagram, Twitter, TwitterIcon as TikTok, Mail } from "lucide-react"

export default function ContactSection() {
  return (
    <footer id="contact" className="py-16 bg-gray-100 dark:bg-zinc-900 border-t border-gray-200 dark:border-zinc-800">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-8 text-gray-900 dark:text-white">Contact Us</h2>
          <Link
            href="mailto:contact@late.ltd"
            className="flex items-center justify-center text-gray-600 dark:text-zinc-400 hover:text-gray-900 dark:hover:text-white transition-colors mb-6"
          >
            <Mail className="w-5 h-5 mr-2" />
            contact@late.ltd
          </Link>

          <p className="text-gray-600 dark:text-zinc-400 mb-4">Follow us on social media:</p>
          <div className="flex justify-center space-x-6">
            <Link
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="text-gray-600 dark:text-zinc-400 hover:text-gray-900 dark:hover:text-white transition-colors"
            >
              <Instagram className="w-6 h-6" />
            </Link>
            <Link
              href="https://tiktok.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="TikTok"
              className="text-gray-600 dark:text-zinc-400 hover:text-gray-900 dark:hover:text-white transition-colors"
            >
              <TikTok className="w-6 h-6" />
            </Link>
            <Link
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Twitter"
              className="text-gray-600 dark:text-zinc-400 hover:text-gray-900 dark:hover:text-white transition-colors"
            >
              <Twitter className="w-6 h-6" />
            </Link>
          </div>

          <div className="mt-12">
            <p className="text-gray-500 dark:text-zinc-500">
              &copy; {new Date().getFullYear()} Late. All Rights Reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}

